MIL_3_Tfile_Hdr_ 115A 94B modeler 25 44CFA118 44CFA118 1 apocalypse Jim@Hauser 0 0 none none 0 0 none 9AE98049 4B8 0 0 0 0 0 0 d50 3                                                                                                                                                                                                                                                                                                                                                                                                  
src_addr:    --------   K- Used by RIP to specify the primary/secondary address, sending out update.   H- By default, this value is set to IPC_ADDR_INVALID (value of -16843010)   F- If src_addr is set to default, IP will set it to the primary address   +  of the interface, sending the packet out.   D- This information is transferred to the ip_encap_req_v4 ICI by the    	UDP layer.strm_index@integer@0@
rem_addr@integer@@
rem_port@integer@-1@
local_port@integer@-1@
status@integer@0@
connection_class@integer@0@
Type of Service@integer@0@
interface received@integer@@
local_minor_port@integer@@
src_addr@integer@-16843010@
inet_support@integer@0@
src_mac_addr@integer@-1@

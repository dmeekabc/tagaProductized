#ifndef _MGEN_VERSION

#define MGEN_VERSION "5.02b"

#endif // _MGEN_VERSION

